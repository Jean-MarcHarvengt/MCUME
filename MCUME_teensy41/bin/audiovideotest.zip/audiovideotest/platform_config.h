#ifndef _PLATFORM_CONFIG_H_
#define _PLATFORM_CONFIG_H_

#define ST7789         1
#define TFTSPI0        1
#define HAS_SND        1

#endif
